package com.example.marting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
