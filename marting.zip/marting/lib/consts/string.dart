import 'package:marting/consts/consts.dart';
const appname="eMart_App";
const appversion="appversion";
const credits="@Khadim Hussain";
const name="Name";
const namehint="Mafi";
const email="Email";
const emailhint="admin@gmail.com";
const password="Password";
const retypepassword="Retype Password";
const passwordhint="******";
const forgetpassword="Forget Password";
const login=" Login";
const signups=" Signup";
const notlogin=" If you have not login to ";
const loginwith=" Login with ";
const privacypolicy=" Privacy Policy ";
const termcontion=" Term & Condition ";
const logged=" Logged in successfully ";
const loggedout=" Logged out successfully ";

//HOME STRING

const home="Home",  catagory="Catagory", cart= "Cart", account="Account";
const searchanythig="Search Anything", todayadeal ="Today Deals", flashsale="Flash Sale", topbrand="Top Brands", topsaller="Top Saller",topgatgory="Top Gatgory", brand="Brand", featurecatagory="Feauter Catagories";


const homeaddress="Home Dress", girlswatches ="Girls Watches", mobilephone="Mobile Phones", boyclasses="Boys Classes", tshirt="Tshirts", girlsdress="girlsdress";
const fetureprduct="Feture Product";
const feturecatgory="Feture Catagor";

//gatagory string

const womencloting="Momen Clothing",
    manclothing="Man Clothing and  Fashion",
    computerassory='Computer Asseries',
    automoible="Auto Mobile",
    kidtoys="Kids Toys",
    sports="Sports",
    juwlelry="Juewlery",
    cellphone="Cell Phone",
    furniture="Furniture";
//item detail  string
const vedio="vedio", review="Review", salepoliy="Sale Policy",returnpolicy="Return Policy", supportpolicy="Support Policy", productlike ="Products may you like";

//profile string
const wishlist= "My wish List", order="My order", message="my Messages";
const featureproduct= "Feature Products";
const oldpass= "Old Password", newpass='New Password';




