export 'color.dart';
export 'string.dart';
export 'images.dart';
export 'string.dart';
export 'package:flutter/material.dart';
export 'package:get/get.dart';
export 'package:velocity_x/velocity_x.dart';
export  'flash_screen.dart';
export 'firbase_console.dart';
export 'AuthController.dart';


//export 'styles.dart';