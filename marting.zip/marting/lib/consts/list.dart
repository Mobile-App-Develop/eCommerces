import 'package:marting/consts/consts.dart';
const sociallist=[
  icFacebookLogo, icGoogleLogo,icTwitterLogo
  
];
const sliderlist=[
  imgSlider1,imgSlider2,imgSlider3,imgSlider4,
];
const sliderlist2=[
  imgSs1,imgSs2,imgSs3,imgSs4,
];
const featureimg1=[
  imgS1,imgS2,imgS3];
const featureimg2=[
  imgS1,imgS2,imgS3];
const featuretitle1=[
 girlswatches, girlsdress,boyclasses];
const featuretitle2=[
  tshirt, mobilephone, girlsdress];


//catrory list

const catagorieslist = [
  womencloting,
  manclothing,
  computerassory,
  automoible,
  kidtoys,
  sports,
  juwlelry,
  cellphone,
  furniture
];
const catagoriesimg = [
  imgFc1,
  imgFc2,
  imgFc3,
  imgFc4,
  imgFc5,
  imgFc6,
  imgFc7,
  imgFc8,
  imgFc9,
];
const itemButtonDetail=[vedio,review,salepoliy,returnpolicy,supportpolicy

];
//profile button
const profileButtonList=[
  order, wishlist, message];
const profileButtonIcons=[
  icOrder, icMessages, icOrders
];




