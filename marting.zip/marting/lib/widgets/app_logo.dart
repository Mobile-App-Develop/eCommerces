import 'package:marting/consts/consts.dart';
Widget applogowidget(){
  return Image.asset(icAppLogo).box.size(70, 70).white.rounded.padding (EdgeInsets.all(8)).make();
}

