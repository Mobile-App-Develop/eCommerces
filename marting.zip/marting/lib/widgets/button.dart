import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:marting/consts/consts.dart';

Widget buttonWidget ({onpress, color, textcolor,String? title}){
  return ElevatedButton(style: ElevatedButton.styleFrom(
    primary: color,
  ),
      onPressed: onpress,  child: title!.text.color(textcolor).make());
}