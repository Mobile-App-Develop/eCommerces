import 'package:marting/consts/consts.dart';
import 'package:marting/consts/style.dart';
class carts extends StatefulWidget {
  const carts({super.key});

  @override
  State<carts> createState() => _cartState();
}

class _cartState extends State<carts> {
  @override
  Widget build(BuildContext context) {


    return Container(
      color: Colors.white,
      child: "Cart is Empty".text.fontFamily(semibold).color(darkFontGrey).make().centered(),
    );
  }
}
