import 'package:marting/consts/consts.dart';
import 'package:marting/consts/style.dart';
import 'package:marting/widgets/button.dart';
import 'package:marting/widgets/home_button.dart';

import '../../consts/list.dart';

class itemDetail extends StatelessWidget {
  const itemDetail({super.key, required this.title});

  final String? title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightGrey,
      appBar: AppBar(
        title: title!.text.color(darkFontGrey).fontFamily(bold).make(),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.share)),
          IconButton(onPressed: () {}, icon: Icon(Icons.favorite_outline))
        ],
      ),
      body: Column(
        children: [
          Expanded(
              child: Padding(
            padding: EdgeInsets.all(8),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //swiper selection
                  VxSwiper.builder(
                      aspectRatio: 16 / 9,
                      autoPlay: true,
                      height: 350,
                      itemCount: 3,
                      itemBuilder: (context, index) {
                        return Image.asset(
                          imgFc5,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        );
                      }),
                  //title and detail section
                  10.heightBox,
                  title!.text
                      .size(16)
                      .fontFamily(semibold)
                      .color(darkFontGrey)
                      .make(),
                  10.heightBox,
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: VxRating(
                      onRatingUpdate: (value) {},
                      normalColor: textfieldGrey,
                      selectionColor: golden,
                      maxRating: 5,
                      count: 5,
                      size: 25,
                      stepInt: true,
                    ),
                  ),
                  10.heightBox,
                  "\$3000"
                      .text
                      .color(redColor)
                      .fontFamily(bold)
                      .size(18)
                      .make(),
                  10.heightBox,
                  Row(
                    children: [
                      Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              "Seller".text.make(),
                              5.heightBox,
                              "In House Brand"
                                  .text
                                  .color(darkFontGrey)
                                  .size(16)
                                  .fontFamily(semibold)
                                  .make(),
                            ],
                          )),
                      const   CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Icon(
                          Icons.message_rounded,
                          color: darkFontGrey,
                        ),
                      ),
                    ],
                  )
                      .box
                      .height(60)
                      .color(textfieldGrey)
                      .padding (const EdgeInsets.symmetric(horizontal: 16))
                      .make(),

                  //8.19 colore section
                  20.heightBox,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 100,
                            child: "Color".text.color(textfieldGrey).make(),
                          ),
                          Row(
                              children: List.generate(
                                  3,
                                      (index) => VxBox()
                                      .size(40, 40)
                                      .roundedFull
                                      .color(Vx.randomPrimaryColor)
                                      .margin(
                                      const EdgeInsets.symmetric(horizontal: 4))
                                      .make())),
                        ],
                      ).box.padding(const EdgeInsets.all(8)).make(),
                      Row(
                        children: [
                          SizedBox(
                            width: 100,
                            child: "Quanity".text.color(textfieldGrey).make(),
                          ),
                          Row(children: [
                            IconButton(
                                onPressed: () {},
                                icon: const Icon(Icons.remove)),
                            "0"
                                .text
                                .size(16)
                                .color(darkFontGrey)
                                .fontFamily(bold)
                                .make(),
                          ]),
                          IconButton(
                              onPressed: () {}, icon: const Icon(Icons.add)),
                          10.widthBox,
                          " (0 available)".text.color(textfieldGrey).make(),
                        ],
                      ),
                    ],
                  ).box.padding(const EdgeInsets.all(8)).make(),
                  Row(children: [
                    SizedBox(
                      width: 100,
                      child: "Total".text.color(darkFontGrey).make(),
                    ),
                    "0.00"
                        .text
                        .color(redColor)
                        .size(16)
                        .fontFamily(bold)
                        .make(),
                  ]),
                  //Description section
                  10.heightBox,
                  'Descption'
                      .text
                      .fontFamily(bold)
                      .color(darkFontGrey)
                      .make(),
                  10.heightBox,
                  'This is dummy item and descripn'
                      .text
                      .color(darkFontGrey)
                      .make(),
                  //button section
                  10.heightBox,
                  ListView(physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    children: List.generate(
                      itemButtonDetail.length,
                          (index) => ListTile(
                        title: itemButtonDetail[index]
                            .text
                            .fontFamily(semibold)
                            .color(darkFontGrey)
                            .make(),
                        trailing: const Icon(Icons.arrow_forward),
                      ),
                    ),
                  ),

                  //product may you like
                  20.heightBox,
                  productlike.text.size(16).color(darkFontGrey).make(),
                  10.heightBox,
                  //copy from home screen
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: List.generate(
                          6,
                              (index) => Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Image.asset(imgP1,
                                  width: 150, fit: BoxFit.cover),
                              10.heightBox,
                              "Laptop 1TB hardDisk"
                                  .text
                                  .color(darkFontGrey)
                                  .make(),
                              10.heightBox,
                              "Rs 889989".text.color(Colors.red).make(),
                            ],
                          )
                              .box
                              .white
                              .roundedSM
                              .padding(const EdgeInsets.all(4))
                              .margin(
                              const EdgeInsets.symmetric(horizontal: 4))
                              .make()),
                    ),
                  ),
                ],
              ),
            ),
              ),
          ),
          SizedBox(
            width: double.infinity,
            height: 60,
            child: buttonWidget(
                color: redColor,
                textcolor: whiteColor,
                title: "Add to Cart",
                onpress: () {}),
          ),
        ],
      ),
    );
  }
}
