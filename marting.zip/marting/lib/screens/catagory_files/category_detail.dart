import 'package:marting/consts/consts.dart';
import 'package:marting/consts/style.dart';
import 'package:marting/screens/catagory_files/item_detail.dart';
import 'package:marting/widgets/bg_widget.dart';

class catagoryDetail extends StatelessWidget {
  const catagoryDetail({super.key, required this.title});

  final String? title;

  @override
  Widget build(BuildContext context) {
    return bgwidget(
        child: Scaffold(
      appBar: AppBar(
        title: title!.text.fontFamily(semibold).white.make(),
      ),
      body: Container(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            SingleChildScrollView(physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal),

            Row(
                children: List.generate(
                    6,
                    (index) => "Baby Cloth"
                        .text
                        .size(12)
                        .color(darkFontGrey)
                        .makeCentered()
                        .box
                        .white
                        .size(100, 50)
                        .rounded
                        .margin(EdgeInsets.symmetric(horizontal: 4))
                        .make())),
            //item countanor
            20.heightBox,

            Expanded(
                child: Container(
              color: lightGrey,
              child: GridView.builder(
                  physics: BouncingScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 6,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      mainAxisExtent: 250,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                      crossAxisCount: 2),
                  itemBuilder: (context, index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.asset(imgP5,
                            width: 200, height: 150, fit: BoxFit.cover),
                        "Laptop 4GB Ram"
                            .text
                            .fontFamily(semibold)
                            .color(darkFontGrey)
                            .make(),
                        10.heightBox,
                        "\$600"
                            .text
                            .fontFamily(semibold)
                            .color(redColor)
                            .make(),
                      ],
                    )
                        .box
                        .white
                        .roundedSM
                        .outerShadow
                        .padding(EdgeInsets.all(12))
                        .margin(EdgeInsets.symmetric(horizontal: 4))
                        .make()
                        .onTap(() {
                      Get.to(() => itemDetail(title: "Dummy item"));
                    });
                  }),
            ))
          ],
        ),
      ),
    ));
  }
}
