import 'package:marting/firbase/firbase_console.dart';

class Firestoreservices{
  static getuser(uid){
    //get user data
    return firestore.collection(usersCollection).where('id', isEqualTo: uid).snapshots();
  }
}